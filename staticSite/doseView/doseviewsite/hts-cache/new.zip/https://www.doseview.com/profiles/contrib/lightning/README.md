

<!DOCTYPE html>
<html lang="en" dir="ltr" prefix="content: http://purl.org/rss/1.0/modules/content/  dc: http://purl.org/dc/terms/  foaf: http://xmlns.com/foaf/0.1/  og: http://ogp.me/ns#  rdfs: http://www.w3.org/2000/01/rdf-schema#  schema: http://schema.org/  sioc: http://rdfs.org/sioc/ns#  sioct: http://rdfs.org/sioc/types#  skos: http://www.w3.org/2004/02/skos/core#  xsd: http://www.w3.org/2001/XMLSchema# ">
  <head>
    <meta charset="utf-8" />
<link rel="canonical" href="https://www.doseview.com/" />
<link rel="shortlink" href="https://www.doseview.com/" />
<meta name="Generator" content="Drupal 10 (https://www.drupal.org)" />
<meta name="MobileOptimized" content="width" />
<meta name="HandheldFriendly" content="true" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<script src="https://cdn.cookielaw.org/scripttemplates/otSDKStub.js" type="text/javascript" charset="UTF-8" data-domain-script="0190d9f2-f541-730a-8c06-5f7f514219a7"></script>
<script type="text/javascript" defer="defer">
  function waitForElm(selector) {
    return new Promise(function (resolve) {
      if (document.querySelector(selector)) {
        return resolve(document.querySelector(selector));
      }
 
      const observer = new MutationObserver(function (mutations) {
        if (document.querySelector(selector)) {
          observer.disconnect();
          resolve(document.querySelector(selector));
        }
      });
 
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    });
  }
 
  function oneTrustAddFont() {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = 'https://fonts.googleapis.com/css?family=Montserrat';
    document.getElementsByTagName('HEAD')[0].appendChild(link);
  }
 
  function addMeta() {
    const meta = document.createElement('meta');
    meta.name = 'viewport';
    meta.content = 'width=device-width, initial-scale=1.0';
    document.getElementsByTagName('head')[0].appendChild(meta);
  }
 
  function oneTrustBannerFooterFix() {
    const divSelector = document.querySelector('#onetrust-button-group-parent');
    const elementDiv = document.createElement('div');
    elementDiv.className = 'ontrust_logo';
    elementDiv.innerHTML = "<div class='green-logo'> onetrust</div><div class='text-logo'>Powered by</div>";
    divSelector.parentNode.insertBefore(elementDiv, divSelector.nextSibling);
 
    document.getElementsByClassName('ot-pc-footer-logo')[0].children[0].removeAttribute('href');
  }
 
  function oneTrustBannerOtherFix() {
    var p = document.querySelectorAll('.ot-accordion-layout p');
    Array.prototype.forEach.call(p, function(el) {
      el.innerHTML = el.innerHTML.replace(/&nbsp;/gi, '');
    });
 
    let tabindex = 2;
    document.querySelectorAll('#onetrust-button-group button, #onetrust-button-group input').forEach(function (element) {
      element.setAttribute('tabindex', String(tabindex));
      if (tabindex === 2) {
        tabindex = 1;
      } else if (tabindex === 1) {
        tabindex = 3;
      } else {
        tabindex++;
      }
    });
    document.querySelector('#onetrust-policy-text a').setAttribute('tabindex', 1);
  }
 
  function oneTrustSettingsButtonFix() {
    const acceptBtn = document.getElementById('accept-recommended-btn-handler');
    const rejectBtn = document.getElementsByClassName('ot-pc-refuse-all-handler')[0];
    const container = document.getElementsByClassName('ot-btn-container')[0];
    container.prepend(acceptBtn, rejectBtn);
  }
 
  function oneTrustSettingsOtherFix() {
    const modelElement = document.getElementById('onetrust-pc-sdk');
    document.addEventListener('focus', function (e) {
      const focusableElements = modelElement.querySelectorAll('a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, *[tabindex], *[contenteditable]');
      if (!Array.from(focusableElements).includes(e.target)) {
        Array.from(focusableElements)[0].focus();
      }
    }, true);
    const tabbingContext = Drupal.tabbingManager.constrain(document.getElementById('onetrust-banner-sdk'),{trapFocus: true});
    const exitTrap = []
    exitTrap.push(modelElement.querySelector('.ot-pc-refuse-all-handler'));
    exitTrap.push(modelElement.querySelector('.onetrust-close-btn-handler'));
    exitTrap.forEach(function(link) {
      link.addEventListener('click', function (e) {
        tabbingContext.release();
      });
    });
  }
 
  oneTrustAddFont();
  addMeta();
 
  document.addEventListener('DOMContentLoaded', function () {
    waitForElm('#onetrust-banner-sdk').then(function () {
      oneTrustBannerFooterFix();
      oneTrustBannerOtherFix();
    });
 
    waitForElm('#onetrust-pc-sdk').then(function () {
      oneTrustSettingsButtonFix();
      oneTrustSettingsOtherFix();
    });
  });
</script>
<script></script>
<link rel="icon" href="/sites/g/files/qhldwo10681/files/doseview_favicon_0.ico" type="image/vnd.microsoft.icon" />

    <title>DoseView</title>
    <link rel="stylesheet" media="all" href="/sites/g/files/qhldwo10681/files/css/css_0yemE9tsvFve6704F8hWz9FrYWzUUWfkrvRwSRE5gN4.css?delta=0&amp;language=en&amp;theme=doseview&amp;include=eJxLyS9OLctMLddPz8lPSszRTS4u1kmBi-Xnp-ekxqfl55UU6xRXFpek5uonJRanAgAzoRTf" />
<link rel="stylesheet" media="all" href="/sites/g/files/qhldwo10681/files/css/css_fMfREOQf8nBis_kxoUc_iIuSKGpIfsAiJyyv-oLd2Ec.css?delta=1&amp;language=en&amp;theme=doseview&amp;include=eJxLyS9OLctMLddPz8lPSszRTS4u1kmBi-Xnp-ekxqfl55UU6xRXFpek5uonJRanAgAzoRTf" />
<link rel="stylesheet" media="all" href="/sites/g/files/qhldwo10681/files/css/css_7VD_u6_TZyNwirUvGpie2B6f4OYw3Mt-M32wp8Wt9rc.css?delta=2&amp;language=en&amp;theme=doseview&amp;include=eJxLyS9OLctMLddPz8lPSszRTS4u1kmBi-Xnp-ekxqfl55UU6xRXFpek5uonJRanAgAzoRTf" />
<link rel="stylesheet" media="all" href="/sites/g/files/qhldwo10681/files/css/css_AuhSj_xcJ08lCtsokAJtlrSqbox_5fcdb1crKGuyH3U.css?delta=3&amp;language=en&amp;theme=doseview&amp;include=eJxLyS9OLctMLddPz8lPSszRTS4u1kmBi-Xnp-ekxqfl55UU6xRXFpek5uonJRanAgAzoRTf" />
<link rel="stylesheet" media="all" href="/sites/g/files/qhldwo10681/files/css/css_8-avdVeC7pTFKIeUECLYx2n45mFg2nSyXPKvw0xWBuQ.css?delta=4&amp;language=en&amp;theme=doseview&amp;include=eJxLyS9OLctMLddPz8lPSszRTS4u1kmBi-Xnp-ekxqfl55UU6xRXFpek5uonJRanAgAzoRTf" />
<link rel="stylesheet" media="all" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" />

    <script src="/sites/g/files/qhldwo10681/files/js/js_QHxEdJ4JXf5GzfVrud-Ckfwdl1hpJnLNZSwy7_prmfc.js?scope=header&amp;delta=0&amp;language=en&amp;theme=doseview&amp;include=eJxVjFsOgDAIBC-k9kzbljQYBNKHXl_95HNmNlusU6p9OeSYyJm1XVA06lu1QTfTk86xwz1wgZQlmGw6YjCt_GtI8P5dxuXiF76qL_0"></script>
<script src="/sites/g/files/qhldwo10681/files/js/js_D_1RwjbtM0vZivb3NvUHJoi2o4Lx2b5O4TW5KQb_FEg.js?scope=header&amp;delta=1&amp;language=en&amp;theme=doseview&amp;include=eJxVjFsOgDAIBC-k9kzbljQYBNKHXl_95HNmNlusU6p9OeSYyJm1XVA06lu1QTfTk86xwz1wgZQlmGw6YjCt_GtI8P5dxuXiF76qL_0"></script>

  </head>
  
  <body class="path-profiles">
    
    <div class="container header full">
      <div class="row">
                    <div id="block-sitebranding" data-block-plugin-id="system_branding_block">
  
    
        <a href="/" rel="home">
      <img src="/sites/g/files/qhldwo10681/files/doseview_otsukalogo_0.png" alt="Home" fetchpriority="high" />
    </a>
      
</div>
<div id="block-fakemenubuttons" data-block-plugin-id="block_content:738648b0-f9b8-47ab-863c-9d475260db63">
  
    
      
  <ul class="nav-btns">
	<li rel-page="3" class="child-dropdown active" style="background-color: #2070b9;"><a href="javascript:void(0);" class="__general-menu-link nav-link dropdown-toggle">U.S. <u>Prescribing information</u>, including <u>BOXED WARNING</u></a>
		<ul class="general-menu-list general-menu-list--sub general-menu-list--sub-1 dropdown-menu">
			<li rel-page="3.1"><a href="https://otsuka-us.com/media/static/Abilify-Asimtufii-PI.pdf" target="_blank">ABILIFY ASIMTUFII<sup>®</sup> (aripiprazole)<b></b></a></li>
		  	<li class="" rel-page="3.2"><a href="https://otsuka-us.com/media/static/Abilify-M-PI.pdf" target="_blank">ABILIFY MAINTENA<sup>®</sup> (aripiprazole)<b></b></a></li>
		</ul> 
	</li>
  	<li class="active" rel-page="0"><a href="#">Overview</a></li>
  	<li rel-page="1"><a href="#">Benchmark</a></li>
  	<li rel-page="2"><a href="#">Calculator</a></li>
</ul>

  </div>

  
            </div>
    </div>
    
    <div class="container main full"></div>

      <div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas>
    
<div class="region-system-page">
    <div class="region region-content">
    <div data-drupal-messages-fallback class="hidden"></div>The requested page could not be found.
  </div>
  
</div>

  </div>

    
    <script type="application/json" data-drupal-selector="drupal-settings-json">{"path":{"baseUrl":"\/","pathPrefix":"","currentPath":"","currentPathIsAdmin":false,"isFront":false,"currentLanguage":"en","themeUrl":"sites\/g\/files\/qhldwo10681\/themes\/site\/themes\/custom\/doseview"},"pluralDelimiter":"\u0003","suppressDeprecationErrors":true,"ajax":[],"user":{"uid":0,"permissionsHash":"e13bd6b59d3a456f4a4bf2bb21214bbdba4303a1fb9896814a5808c22b0e81d1"}}</script>
<script src="/sites/g/files/qhldwo10681/files/js/js_KeVRNMfeSGnKE_v-Myjl_8ktAHoULFYS8yQaHdOBwJM.js?scope=footer&amp;delta=0&amp;language=en&amp;theme=doseview&amp;include=eJxVjFsOgDAIBC-k9kzbljQYBNKHXl_95HNmNlusU6p9OeSYyJm1XVA06lu1QTfTk86xwz1wgZQlmGw6YjCt_GtI8P5dxuXiF76qL_0"></script>
<script src="/sites/g/files/qhldwo10681/files/js/js_wOmwoVjYX4bvh2wdrdSoWOKvB8JbiBfPL4WQHBJsXzU.js?scope=footer&amp;delta=1&amp;language=en&amp;theme=doseview&amp;include=eJxVjFsOgDAIBC-k9kzbljQYBNKHXl_95HNmNlusU6p9OeSYyJm1XVA06lu1QTfTk86xwz1wgZQlmGw6YjCt_GtI8P5dxuXiF76qL_0"></script>
<script src="/sites/g/files/qhldwo10681/files/js/js_uGYWfUBAcFgG1X8VPnPIOAZY9NLkRId0R2A5wh_GPxQ.js?scope=footer&amp;delta=2&amp;language=en&amp;theme=doseview&amp;include=eJxVjFsOgDAIBC-k9kzbljQYBNKHXl_95HNmNlusU6p9OeSYyJm1XVA06lu1QTfTk86xwz1wgZQlmGw6YjCt_GtI8P5dxuXiF76qL_0"></script>
<script src="/sites/g/files/qhldwo10681/files/js/js_-vvAbQih_E9-Nbm3lnIg56EYjCeE9wuiwg93w9gxKS0.js?scope=footer&amp;delta=3&amp;language=en&amp;theme=doseview&amp;include=eJxVjFsOgDAIBC-k9kzbljQYBNKHXl_95HNmNlusU6p9OeSYyJm1XVA06lu1QTfTk86xwz1wgZQlmGw6YjCt_GtI8P5dxuXiF76qL_0"></script>

  </body>
</html>
